<!DOCTYPE html>

<html lang="en">

@include('admin.layout.head')

<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

@include('admin.layout.header')

<div class="clearfix"> </div>

@include('admin.layout.container')

@include('admin.layout.footer')

@include('admin.layout.scripts')

    </body>

</html>
