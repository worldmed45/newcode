<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-7">
  <div class="panel panel-inverse">
    <div class="panel-heading">
      <h4 class="panel-title">My References</h4>
    </div>
    <div class="panel-body table-responsive">
     <table class="table table-striped">
     	<tr>
            <th>S.no</th>
     		<th>Full Name</th>
            <th>Joining Date</th>
     		
     	</tr>
    <?php $count=1; ?>
     	<?php $__currentLoopData = $refers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
     	<tr>
            <td><?php echo $count;?></td>
     		<td><?php echo e($ref->name); ?></td>
            <td><?php echo e($ref->created_at); ?></td>
     		
     	</tr>
       <?php $count++;?>
     	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </table>
     <?php echo $refers->render(); ?>
   </div>
 </div>
</div> 
<div class="col-md-5">
    <div class="panel panel-inverse" data-sortable-id="index-1">
    <div class="panel-heading">
      <h4 class="panel-title">Referal URL</h4>
    </div>
    <div class="panel-body">
        <div class="form-group">
        <div class="input-group">
            <input type="text" class="form-control input-lg" id="rlink" value="<?php echo e(url('/')); ?>/register/<?php echo e(Auth::user()->username); ?>" readonly>
            <span class="input-group-addon btn btn-success" id="copybtn">Copy</span>
        </div>
    </div>
    </div>
    </div>
    
</div> 
</div>

<!--Copy Data -->
<script type="text/javascript">
  document.getElementById("copybtn").onclick = function() 
  {
    document.getElementById('rlink').select();
    document.execCommand('copy');
  }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>