<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-title">
                  <div class="caption font-red-sunglo">
<i class="icon-settings font-red-sunglo"></i>
<span class="caption-subject bold uppercase">ICO Management</span>
</div>
                     <div class="actions">
                        <a class="btn btn-circle btn-lg btn-success" data-toggle="modal" data-target="#addico">
                           <i class="icon-plus"></i> New ICO
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                      <table class="table table-striped table-bordered table-hover order-column">
                      	<tr>
                          <th>Start Date</th>
                      		<th>End Date</th>
                      		<th><?php echo e($gnl->cur); ?> Token</th>
                          <th>Price (USD)</th>
                      		<th>Sold</th>
                      		<th>Status</th>
                      		<th>Action</th>
                      	</tr>
                      	<?php $__currentLoopData = $icos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
              <td><?php echo e($ico->start); ?></td>
							<td><?php echo e($ico->end); ?></td>
							<td><?php echo e($ico->quant); ?> <?php echo e($gnl->cur); ?></td>
              <td><?php echo e($ico->price); ?> USD</td>
							<td><?php echo e($ico->sold); ?> <br/>
                <div class="progress">
                  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo e(($ico->sold/$ico->quant)*100); ?>"
                  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(($ico->sold/$ico->quant)*100); ?>%">
                    <?php echo e(($ico->sold/$ico->quant)*100); ?>%
                  </div>
                </div>
              </td>
							<td>
            
            <?php if($ico->status == 1): ?>
            <span style="background-color:#ffcc66; color: #fff; padding:5px;">Runing</span>
            <?php elseif($ico->status == 0): ?>
            <span style="background-color:#00ccff; color: #fff; padding:5px;">Upcoming</span>
            <?php else: ?>
            <span style="background-color:red; color: #fff; padding:5px;">Completed</span>
            <?php endif; ?>
							                  </td>
							<td>
								 <a class="btn btn-circle btn-icon-only btn-warning" data-toggle="modal" data-target="#edit<?php echo e($ico->id); ?>">
		                           <i class="fa fa-edit"></i>
		                        </a>
								
							</td>
						</tr>
	<div id="edit<?php echo e($ico->id); ?>" class="modal fade" role="dialog">
          <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit ICO</h4>
              </div>
              <div class="modal-body">
                <form role="form" method="POST" action="<?php echo e(route('ico.update', $ico)); ?>">
                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('put')); ?>

                 <div class="form-group">
                        <label>ICO Start Date</label>
                        <div class="input-group">
                          <input type="text" name="start" data-date-format="yyyy-mm-dd" class="form-control form-control-inline  date-picker" value="<?php echo e($ico->start); ?>" readonly />
              <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label>ICO End Date</label>
                        <div class="input-group">
                        	<input type="text" name="end" data-date-format="yyyy-mm-dd" class="form-control form-control-inline  date-picker" value="<?php echo e($ico->end); ?>" readonly />
							<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="quant" ><?php echo e($gnl->cur); ?> Token (Total Quantity to Sell)</label>
                        <input type="text" value="<?php echo e($ico->quant); ?>" name="quant" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="text" value="<?php echo e($ico->price); ?>" name="price" class="form-control">
                    </div>
                     <div class="form-group">
                        <label for="sold">Sold</label>
                        <input type="text" value="<?php echo e($ico->sold); ?>" name="sold" class="form-control">
                    </div>
                    <div class="form-group">
                    	<label>Status</label>
                    	<select class="form-control" name="status">
                    		<option value="1" <?php echo e($ico->status == 1 ? 'selected' : ''); ?>>Runing</option>
                        <option value="0" <?php echo e($ico->status == 0 ? 'selected' : ''); ?>>Upcoming</option>
                        <option value="3" <?php echo e($ico->status == 3 ? 'selected' : ''); ?>>Completed</option>
                    	</select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-success btn-block" >Save</button>
                    </div>
                </form>
              </div>
            </div>

          </div>
        </div>
                      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                </div>
            </div>
        </div>
    </div>
      <!-- Add Test -->
    <div id="addico" class="modal fade" role="dialog">
          <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">New ICO</h4>
              </div>
              <div class="modal-body">
                <form role="form" method="POST" action="<?php echo e(route('ico.store')); ?>">
                 <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                        <label>ICO Start Date</label>
                        <div class="input-group">
                          <input type="text" name="start" data-date-format="yyyy-mm-dd" class="form-control form-control-inline  date-picker" readonly />
              <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label>ICO End Date</label>
                        <div class="input-group">
                        	<input type="text" name="end" data-date-format="yyyy-mm-dd" class="form-control form-control-inline  date-picker" readonly />
							<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="quant" ><?php echo e($gnl->cur); ?> Token (Total Quantity to Sell)</label>
                        <input type="text" name="quant" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="text" name="price" class="form-control">
                    </div>
                    <div class="form-group">
                    	<label>Status</label>
                    	<select class="form-control" name="status">
                        <option value="0" selected>Upcoming</option>
                    		<option value="1">Running</option>
                    	</select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-success btn-block" >Save</button>
                    </div>
                </form>
              </div>
            </div>

          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>