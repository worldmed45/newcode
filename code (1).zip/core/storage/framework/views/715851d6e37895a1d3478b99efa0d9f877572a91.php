<?php $__env->startSection('content'); ?>
<div class="col-md-8 col-md-offset-2">
    

                    <form class="login-form" role="form" method="POST" action="<?php echo e(url('/admin/register')); ?>">
                        <?php echo e(csrf_field()); ?>

                         <h3 class="font-green">Register New Admin</h3>
<hr/>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Full Name</label>
                   <input id="name"  class="form-control placeholder-no-fix" type="text" placeholder="Full Name" name="name" value="<?php echo e(old('name')); ?>" autofocus>
                </div>
                 <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">E-Mail Address</label>
                   <input id="email"  class="form-control placeholder-no-fix" type="text" placeholder="E-Mail Address" name="email" value="<?php echo e(old('email')); ?>" autofocus>
                </div>
                 <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Username</label>
                   <input id="email"  class="form-control placeholder-no-fix" type="text" placeholder="Username" name="username" value="<?php echo e(old('username')); ?>" autofocus>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                   <input id="password" placeholder="Password"  class="form-control placeholder-no-fix" type="password"  name="password">
                </div>
                 <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Confirm Password</label>
                   <input id="password-confirm" placeholder="Confirm Password"  class="form-control placeholder-no-fix" type="password"  name="password_confirmation">
                    <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>


                <div class="form-actions">
                    <button type="submit" id="register-submit-btn" class="btn btn-success btn-lg btn-block btn-success uppercase pull-right">Register</button>
                </div>
                    </form>
         </div>     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>