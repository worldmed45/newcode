<?php $__env->startSection('content'); ?>
<section class="contact-section contact-bg" id="contact" style="background-image: url(<?php echo e(asset('assets/images/logo/bc.jpg')); ?>);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="contact-form-wrapper">
                    <h2 class="text-uppercase text-center">Reset Password</h2>
                    <form method="POST" action="<?php echo e(route('forgot.pass')); ?>">
                        <?php echo e(csrf_field()); ?>

                                <input id="email" type="email" placeholder="Email Address" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
        
                              <input type="submit" value="Send Reset Link">
                    </form>
                       </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>