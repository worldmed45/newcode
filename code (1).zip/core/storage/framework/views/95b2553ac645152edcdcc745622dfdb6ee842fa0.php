<div class="page-sidebar-wrapper">

    <div class="page-sidebar navbar-collapse collapse">

        <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">

            <li class="sidebar-toggler-wrapper hide">
                <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
                <div class="sidebar-toggler"> </div>
                <!-- END SIDEBAR TOGGLER BUTTON -->
            </li>

            <li class="nav-item  <?php if(request()->path() == 'admin/home'): ?> active open <?php endif; ?>">
                <a href="<?php echo e(url('admin/home')); ?>" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Dashboard</span>
                    <span class="selected"></span>
                </a>
            </li>
            <li class="nav-item
            <?php if(request()->path() == 'admin/users'): ?> active open
                <?php elseif(request()->path() == 'admin/user/search'): ?> active open
                <?php elseif(request()->path() == 'admin/user-banned'): ?> active open
                <?php elseif(request()->path() == 'admin/broadcast'): ?> active open
                <?php elseif(request()->path() == 'admin/subscribers'): ?> active open
            <?php endif; ?>">
            <a href="#" class="nav-link nav-toggle">
                <i class="fa fa-users"></i>
                <span class="title">User Management</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/users'): ?> active open 
                    <?php elseif(request()->path() == 'admin/user/search'): ?> active open
                    <?php endif; ?>">
                    <a href="<?php echo e(route('users')); ?>" class="nav-link ">
                        <i class="fa fa-users"></i>
                        <span class="title">Users</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/broadcast'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('broadcast')); ?>" class="nav-link ">
                        <i class="icon-envelope"></i>
                        <span class="title">Broadcast Email</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/subscribers'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('admin.subscribers')); ?>" class="nav-link ">
                        <i class="fa fa-users"></i>
                        <span class="title">Subscribers</span>
                    </a>
                </li>    
                <li class="nav-item <?php if(request()->path() == 'admin/user-banned'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('user.ban')); ?>" class="nav-link ">
                        <i class="icon-user"></i>
                        <span class="title">Banned Users</span>
                    </a>
                </li>                 
            </ul>
        </li>
            <li class="nav-item  <?php if(request()->path() == 'admin/gateway'): ?> active open <?php endif; ?>">
                <a href="<?php echo e(route('gateway.index')); ?>" class="nav-link nav-toggle">
                    <i class="fa fa-credit-card"></i>
                    <span class="title">Payment Gateway</span>
                    <span class="selected"></span>
                </a>
            </li>
              <li class="nav-item  <?php if(request()->path() == 'admin/sell-log'): ?> active open <?php endif; ?>">
                <a href="<?php echo e(route('sellLog')); ?>" class="nav-link nav-toggle">
                    <i class="fa fa-shopping-cart "></i>
                    <span class="title">Sell Log</span>
                </a>
            </li>
             <li class="nav-item  <?php if(request()->path() == 'admin/ico'): ?> active open <?php endif; ?>">
                <a href="<?php echo e(route('ico.index')); ?>" class="nav-link nav-toggle">
                    <i class="fa fa-calendar-check-o "></i>
                    <span class="title">Manage ICO</span>
                </a>
            </li>
            <li class="nav-item <?php if(request()->path() == 'admin/general'): ?> active open
            <?php elseif(request()->path() == 'admin/logo'): ?> active open 
            <?php elseif(request()->path() == 'admin/template'): ?> active open 
            <?php elseif(request()->path() == 'admin/sms-api'): ?> active open 
            <?php endif; ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-cogs"></i>
                    <span class="title">Website Control</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item <?php if(request()->path() == 'admin/general'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('general')); ?>" class="nav-link ">
                            <i class="fa fa-cog"></i>
                            <span class="title">General Settings</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/logo'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('logo')); ?>" class="nav-link ">
                            <i class="fa fa-picture-o"></i>
                            <span class="title">Logo and Icon</span>
                        </a>
                    </li>
                     <li class="nav-item <?php if(request()->path() == 'admin/template'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('template')); ?>" class="nav-link ">
                            <i class="fa fa-envelope"></i>
                            <span class="title">Email Template</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/sms-api'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('sms.api')); ?>" class="nav-link ">
                            <i class="fa fa-envelope"></i>
                            <span class="title">SMS API</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item <?php if(request()->path() == 'admin/faq'): ?> active open
            <?php elseif(request()->path() == 'admin/road'): ?> active open 
            <?php elseif(request()->path() == 'admin/testim'): ?> active open 
            <?php elseif(request()->path() == 'admin/services'): ?> active open 
            <?php elseif(request()->path() == 'admin/teams'): ?> active open 
            <?php elseif(request()->path() == 'admin/banner'): ?> active open 
            <?php elseif(request()->path() == 'admin/about'): ?> active open 
            <?php elseif(request()->path() == 'admin/subsc'): ?> active open 
            <?php elseif(request()->path() == 'admin/footer'): ?> active open 
            <?php elseif(request()->path() == 'admin/background'): ?> active open 
            <?php endif; ?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-cogs"></i>
                    <span class="title">Frontend Content</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item <?php if(request()->path() == 'admin/banner'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('banner')); ?>" class="nav-link ">
                            <i class="fa fa-cog"></i>
                            <span class="title">Banner</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/about'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('about')); ?>" class="nav-link ">
                            <i class="fa fa-cog"></i>
                            <span class="title">About Section</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/faq'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('faq.index')); ?>" class="nav-link ">
                            <i class="fa fa-question"></i>
                            <span class="title">Faq</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/road'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('road.index')); ?>" class="nav-link ">
                            <i class="fa fa-cog"></i>
                            <span class="title">Road Map</span>
                        </a>
                    </li>
                     <li class="nav-item <?php if(request()->path() == 'admin/testim'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('testim.index')); ?>" class="nav-link ">
                            <i class="fa fa-cog""></i>
                            <span class="title">Testimonial</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/services'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('services.index')); ?>" class="nav-link ">
                            <i class="fa fa-cog""></i>
                            <span class="title">Services</span>
                        </a>
                    </li>
                      <li class="nav-item <?php if(request()->path() == 'admin/teams'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('teams.index')); ?>" class="nav-link ">
                            <i class="fa fa-users""></i>
                            <span class="title">Team Members</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(request()->path() == 'admin/subsc'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('subsc')); ?>" class="nav-link ">
                            <i class="fa fa-cog""></i>
                            <span class="title">Subscriber Section</span>
                        </a>
                    </li> 
                     <li class="nav-item <?php if(request()->path() == 'admin/footer'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('footer')); ?>" class="nav-link ">
                            <i class="fa fa-cog""></i>
                            <span class="title">Footer And ICO Section</span>
                        </a>
                    </li> 
                    <li class="nav-item <?php if(request()->path() == 'admin/background'): ?> active open <?php endif; ?>">
                        <a href="<?php echo e(route('background')); ?>" class="nav-link ">
                            <i class="fa fa-picture-o""></i>
                            <span class="title">Background Image</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </li>
</ul>
</div>
</div>