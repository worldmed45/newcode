<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-red-sunglo">
                    <i class="icon-settings font-red-sunglo"></i>
                    <span class="caption-subject bold uppercase">Frontend Content </span>
                </div>
            </div>
            <div class="portlet-body">
                <form role="form" method="POST" action="<?php echo e(route('frontend.update')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                   
                            <div class="form-group col-md-4">
                                <label for="ban_title">ICO Title</label>
                                <input type="text" value="<?php echo e($frontend->ban_title); ?>" name="ban_title" class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="ban_price">ICO Price</label>
                                <input type="text" value="<?php echo e($frontend->ban_price); ?>" name="ban_price" class="form-control">
                            </div>
                            <div class="form-group col-md-3">
                                <label for="ban_date">ICO End Date</label>
                               <div class="input-group">
                                <input type="text" class="form-control form-control-inline input-medium date-picker" readonly name="ban_date" data-date-format="yyyy-mm-dd" value="<?php echo e($frontend->ban_date); ?>">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                            </div>
                            </div>
                            <div class="form-group">
                                <label for="ban_details">Banner Details</label>
                               <textarea name="ban_details" class="form-control">
                                   <?php echo $frontend->ban_details; ?>

                               </textarea>
                            </div>
                             <div class="form-group col-md-6">
                                <label for="about_title">About Title</label>
                                <input type="text" value="<?php echo e($frontend->about_title); ?>" name="about_title" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="video">About Video URL</label>
                                <input type="text" value="<?php echo e($frontend->video); ?>" name="video" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="about_content">About Content</label>
                               <textarea name="about_content" class="form-control">
                                   <?php echo $frontend->about_content; ?>

                               </textarea>
                            </div>
                             <div class="form-group">
                                <label for="serv_title">Service Title</label>
                                <input type="text" value="<?php echo e($frontend->serv_title); ?>" name="serv_title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="serv_details">Service Details</label>
                               <textarea name="serv_details" class="form-control">
                                   <?php echo $frontend->serv_details; ?>

                               </textarea>
                            </div>
                            <div class="form-group">
                            <label for="road_title">Road Map Title</label>
                                <input type="text" value="<?php echo e($frontend->road_title); ?>" name="road_title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="road_details">Road Map Details</label>
                               <textarea name="road_details" class="form-control">
                                   <?php echo $frontend->road_details; ?>

                               </textarea>
                            </div>
                            <div class="form-group">
                            <label for="team_title">Team Section Title</label>
                                <input type="text" value="<?php echo e($frontend->team_title); ?>" name="team_title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="team_details">Team Section Details</label>
                               <textarea name="team_details" class="form-control">
                                   <?php echo $frontend->team_details; ?>

                               </textarea>
                            </div>
                            <div class="form-group">
                            <label for="testm_title">Testimonial Section Title</label>
                                <input type="text" value="<?php echo e($frontend->testm_title); ?>" name="testm_title" class="form-control">
                            </div>
                             <div class="form-group">
                                <label for="testm_details">Testimonial Section Details</label>
                               <textarea name="testm_details" class="form-control">
                                   <?php echo $frontend->testm_details; ?>

                               </textarea>
                            </div>
                            <div class="form-group">
                            <label for="faq_title">Faq Section Title</label>
                                <input type="text" value="<?php echo e($frontend->faq_title); ?>" name="faq_title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="faq_details">Faq Section Details</label>
                               <textarea name="faq_details" class="form-control">
                                   <?php echo $frontend->faq_details; ?>

                               </textarea>
                            </div>
                             <div class="form-group">
                            <label for="subs_title">Subscription Section Title</label>
                                <input type="text" value="<?php echo e($frontend->subs_title); ?>" name="subs_title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="subs_details">Subscription Section Details</label>
                               <textarea name="subs_details" class="form-control">
                                   <?php echo $frontend->subs_details; ?>

                               </textarea>
                            </div>
                             <div class="form-group">
                                <label for="footer1">Left Footer Section</label>
                               <textarea name="footer1" class="form-control">
                                   <?php echo $frontend->footer1; ?>

                               </textarea>
                            </div> 
                            <div class="form-group">
                                <label for="footer2">Right Footer Section</label>
                               <textarea name="footer2" class="form-control">
                                   <?php echo $frontend->footer2; ?>

                               </textarea>
                            </div>
                            <div class="form-group">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail">
                                <img src="<?php echo e(asset('assets/images/section')); ?>/<?php echo e($frontend->secbg1); ?>" alt="" /> </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                    <span class="btn btn-success btn-file">
                                        <span class="fileinput-new"> Change Photo </span>
                                        <span class="fileinput-exists"> Change </span>
                                        <input type="file" name="secbg1"> </span>
                                        <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail">
                                <img src="<?php echo e(asset('assets/images/section')); ?>/<?php echo e($frontend->secbg2); ?>" alt="" /> </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                    <span class="btn btn-success btn-file">
                                        <span class="fileinput-new"> Change Photo </span>
                                        <span class="fileinput-exists"> Change </span>
                                        <input type="file" name="secbg2"> </span>
                                        <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail">
                                <img src="<?php echo e(asset('assets/images/section')); ?>/<?php echo e($frontend->secbg3); ?>" alt="" /> </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                    <span class="btn btn-success btn-file">
                                        <span class="fileinput-new"> Change Photo </span>
                                        <span class="fileinput-exists"> Change </span>
                                        <input type="file" name="secbg3"> </span>
                                        <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail">
                                <img src="<?php echo e(asset('assets/images/section')); ?>/<?php echo e($frontend->secbg4); ?>" alt="" /> </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                    <span class="btn btn-success btn-file">
                                        <span class="fileinput-new"> Change Photo </span>
                                        <span class="fileinput-exists"> Change </span>
                                        <input type="file" name="secbg4"> </span>
                                        <a href="javascript:;" class="btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>White Paper</label>
                                <input type="file" name="whitepaper" class="form-control">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-lg btn-success btn-block" >Update</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>


        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>