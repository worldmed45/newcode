<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-red-sunglo">
                    <i class="icon-settings font-red-sunglo"></i>
                    <span class="caption-subject bold uppercase">Banner Content </span>
                </div>
            </div>
            <div class="portlet-body">
                <form role="form" method="POST" action="<?php echo e(route('banner.update')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group col-md-4">
                        <label for="ban_title" style="font-size: 20px;">ICO Title</label>
                        <input type="text" value="<?php echo e($frontend->ban_title); ?>" name="ban_title" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="ban_price" style="font-size: 20px;">ICO Price</label>
                        <input type="text" value="<?php echo e($frontend->ban_price); ?>" name="ban_price" class="form-control">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="ban_date" style="font-size: 20px;">ICO End Date</label>
                        <div class="input-group">
                            <input type="text" class="form-control form-control-inline input-medium date-picker" readonly name="ban_date" data-date-format="yyyy-mm-dd" value="<?php echo e($frontend->ban_date); ?>">
                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="font-size: 20px;">Banner Details</label>
                        <textarea name="ban_details" class="form-control" rows="8">
                            <?php echo $frontend->ban_details; ?>

                        </textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-success btn-block" >Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>