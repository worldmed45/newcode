<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12">
  <div class="panel panel-inverse">
    <div class="panel-heading">
      <h4 class="panel-title">Select Payment Gateways</h4>
    </div>
    <div class="panel-body table-responsive">
        <?php $__currentLoopData = $gates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="panel panel-primary">
                <div class="panel-heading">
                  <h4 class="panel-title"><?php echo e($gate->name); ?></h4>
                </div>
                <div class="panel-body text-center">
                    <img src="<?php echo e(asset('assets/images/gateway')); ?>/<?php echo e($gate->gateimg); ?>" style="width:100%">
               </div>
               <div class="panel-footer">
                    <button class="btn btn-success btn-block" data-toggle="modal" data-target="#buyModal<?php echo e($gate->id); ?>">Select  </button>
               </div>
            </div>   
        </div>
            <!--Buy Modal -->
<div id="buyModal<?php echo e($gate->id); ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Buy ICO via <strong><?php echo e($gate->name); ?></strong></h4>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(route('buy.preview')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="gateway" value="<?php echo e($gate->id); ?>">
            <h5 style="color: green; text-align: center;">1 <?php echo e($gnl->cur); ?> = <?php echo e($ico->price); ?> USD</h5>
            <h5 style="color: #0066cc; text-align: center;"><?php echo e($ico->quant-$ico->sold); ?> <?php echo e($gnl->cur); ?> Available</h5>
            <hr/>
            <div class="form-group">
                <div class="input-group">
                  <input type="text" name="amount" class="form-control" id="amount" required>
                  <span class="input-group-addon">
                    <?php echo e($gnl->cur); ?>

                  </span>
                </div>
           </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">
                    Preview
                </button>
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
 </div>
</div> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>