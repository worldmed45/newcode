<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8 col-md-offset-2">
  <div class="panel panel-inverse">
    <div class="panel-heading">
      <h4 class="panel-title">Preview of Buying ICO</h4>
    </div>
    <div class="panel-body table-responsive text-center">
       <ul class="list-group">
       		<li class="list-group-item"><?php echo e($gnl->cur); ?> Amount: <strong><?php echo e($amount); ?></strong> <?php echo e($gnl->cursym); ?></li>
       		<li class="list-group-item"><?php echo e($gnl->cur); ?> Price: <strong><?php echo e($ico->price); ?></strong> USD</li>
       		<?php if($gate->id == 3 || $gate->id == 6 || $gate->id == 7 || $gate->id == 8): ?> 
       		<li class="list-group-item">Total Payable: <strong><?php echo e($btc); ?></strong> BTC</li>
       		<li class="list-group-item">Payment Gateway: <strong><?php echo e($gate->name); ?></strong></li>
           <?php else: ?>
       		<li class="list-group-item">Total Payable: <strong><?php echo e($usd); ?></strong> USD</li>
       		<li class="list-group-item">Payment Gateway: <strong><?php echo e($gate->name); ?></strong></li>
       		<?php endif; ?>
       </ul>
   </div>
   <div class="panel-footer">
   	<a class="btn btn-success btn-lg btn-block" href="<?php echo e(route('buy.confirm')); ?>">
   		Pay Now
   	</a>
   </div>
 </div>
</div> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>