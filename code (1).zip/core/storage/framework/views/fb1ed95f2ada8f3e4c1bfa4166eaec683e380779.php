<?php $__env->startSection('content'); ?>
    <section>
        <?php echo $send_pay_request; ?>

    </section>
 <script type="text/javascript">
           $(document).ready(function(){
               $( "body" ).contextmenu(function() {
                  alert( "Right Click Not Allow!" );
                });
                  $("#pament_form" ).submit();
           });
       </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>