<!DOCTYPE html>

<html lang="en">

<?php echo $__env->make('admin.layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

<?php echo $__env->make('admin.layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="clearfix"> </div>

<?php echo $__env->make('admin.layout.container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin.layout.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </body>

</html>
