<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-red-sunglo">
                    <i class="icon-settings font-red-sunglo"></i>
                    <span class="caption-subject bold uppercase">Footer Section Content </span>
                </div>
            </div>
            <div class="portlet-body">
                <form role="form" method="POST" action="<?php echo e(route('footer.update')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                                <h4 for="footer1">Left Footer Section</h4>
                               <textarea name="footer1" class="form-control">
                                   <?php echo $frontend->footer1; ?>

                               </textarea>
                            </div> 
                            <div class="form-group">
                                <h4 for="footer2">ICO Calendar Heading</h4>
                               <textarea name="footer2" class="form-control">
                                   <?php echo $frontend->footer2; ?>

                               </textarea>
                            </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-success btn-block" >Update</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>