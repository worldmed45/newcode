<!DOCTYPE html>
<html>
<head>
	<title>Website</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		
</head>
<body>
	<div class="container">
	<div class="row">
		<div class="navbar-default">
			<ul class="nav navbar-nav">
				<li><a href="<?php echo e(url('/')); ?>"><?php echo e($gnl->title); ?></a></li>
				<?php if(auth()->guard()->check()): ?>
				<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
				<?php else: ?>
				<li><a href="<?php echo e(route('login')); ?>">Login</a></li>
				<li><a href="<?php echo e(route('register')); ?>">Register</a></li>
				<?php endif; ?>
			</ul>
		</div>
</div>
</div>
</body>
</html>