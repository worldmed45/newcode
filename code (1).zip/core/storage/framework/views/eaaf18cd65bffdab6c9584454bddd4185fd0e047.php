<div class="col-md-4">
                <ul class="list-group">
                    <li class="list-group-item">
                        <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                    </li>
                    <li class="list-group-item">
                        <a href="<?php echo e(route('go2fa')); ?>"><i class="fa fa-shield" aria-hidden="true"></i> <span>Security</span></a>
                    </li>
                    <li class="list-group-item">
                        <a href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                        Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
            </ul>
        </div>