<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12">
  <div class="panel panel-inverse">
    <div class="panel-heading">
      <h4 class="panel-title"><?php echo e($gnl->cur); ?> Purchase Log</h4>
    </div>
    <div class="panel-body table-responsive">
     <table class="table table-striped">
     	<tr>
            <th>Amount</th>
            <th><?php echo e($gnl->cur); ?> Buying Price</th>
            <th>ICO Start Date</th>
            <th>ICO End Date</th>
     		<th>Buying Date</th>
            <th>Payment Gateway</th>
     	</tr>
     	<?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     	<tr>
            <td><?php echo e($cn->amount); ?> <?php echo e($gnl->cur); ?></td>
            <td><?php echo e($cn->ico->price); ?> USD</td>
            <td><?php echo e($cn->ico->start); ?></td>
            <td><?php echo e($cn->ico->end); ?></td>
     		<td><?php echo e($cn->created_at); ?></td>
            <td><?php echo e($cn->gateway->name); ?></td>
     	</tr>
     	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </table>
   </div>
 </div>
</div> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>