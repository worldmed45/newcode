<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
       <div class="panel panel-inverse">
                <div class="panel-heading">
                   <h4 class="panel-title">ICO Calender</h4>
                </div>
            <div class="panel-body">
        <?php $__currentLoopData = $nexts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $next): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="panel panel-<?php echo e($next->status == 1? 'success': 'inverse'); ?>">
                        <div class="panel-heading">
                           <h4 class="panel-title"><?php echo e($next->status == 1? 'Runing': 'Upcoming'); ?> ICO 
                           </h4>
                        </div>
                        <div class="panel-body text-center">
                            <ul class="list-group">
                                <li class="list-group-item">Price: <strong><?php echo e($next->price); ?> USD</strong></li>
                                <li class="list-group-item">Start At: <strong><?php echo e($next->start); ?></strong></li>
                                <li class="list-group-item">End At: <strong><?php echo e($next->end); ?></strong></li>
                                <li class="list-group-item">Total Quantity: <strong><?php echo e($next->quant); ?> <?php echo e($gnl->cur); ?></strong></li>
                                <li class="list-group-item">Sold: <strong><?php echo e($next->sold); ?> <?php echo e($gnl->cur); ?></strong></li>
                                <li class="list-group-item">
                                      <div class="progress">
                                      <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo e(round(($next->sold/$next->quant)*100,2)); ?>"
                                      aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(round(($next->sold/$next->quant)*100,2)); ?>%">
                                      </div>
                                    </div>
                                    <span style="color:#0066cc;"><?php echo e(round(($next->sold/$next->quant)*100,2)); ?>% Sold</span>
                                </li>
                            </ul>
                        </div>
                         <?php if($next->status==1): ?>
                          <div class="panel-footer text-center">
                                <a class="btn btn-success btn-lg btn-block" href="<?php echo e(route('buy.ico')); ?>">Buy Now</a>
                            </div>
                          <?php else: ?>
                          <div class="panel-footer text-center">
                                <h4 style="color:#ddd;">Coming Soon!</h4>
                            </div>
                        <?php endif; ?>
                    </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>