<!DOCTYPE html>
<html>
<head>
	<title>Website</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		
</head>
<body>
	<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<ul>
				<?php if(auth()->guard()->check()): ?>
				<li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
				<?php else: ?>
				<li><a href="<?php echo e(route('login')); ?>">Login</a></li>
				<li><a href="<?php echo e(route('register')); ?>">Register</a></li>
				<?php endif; ?>
			</ul>
		</div>
</div>
</div>
</body>
</html>