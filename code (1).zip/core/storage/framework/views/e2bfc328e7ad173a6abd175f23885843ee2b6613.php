<div id="sidebar" class="sidebar">
  <div data-scrollbar="true" data-height="100%">
    <ul class="nav text-center">
      <li class="nav-profile">
        <div class="info text-center">
          <img src="<?php echo e(asset('assets/images/profile')); ?>/<?php echo e(Auth::user()->photo); ?>" class="img-responsive img-rounded" style="max-height:70px; max-width: 70px; margin: auto;">
          <a href="<?php echo e(route('profile')); ?>" style="text-decoration: none; font-size: 15px; color: #ddd;"><?php echo e(Auth::user()->name); ?></a>

          <small><?php echo e(Auth::user()->username); ?></small>
        </div>
      </li>
    </ul>
    <ul class="nav" style="text-transform: uppercase;">
      <li class="<?php if(request()->path() == 'home'): ?> active <?php endif; ?>"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li> 
       <li class="<?php if(request()->path() == 'home/profile'): ?> active <?php endif; ?>"><a href="<?php echo e(route('profile')); ?>"><i class="fa fa-user"></i> <span>Profile</span></a></li> 
      <li class="<?php if(request()->path() == 'home/referal'): ?> active <?php endif; ?>"><a href="<?php echo e(route('referal')); ?>"><i class="fa fa-users" aria-hidden="true"></i> <span>Reference log</span></a></li>
      <li class="<?php if(request()->path() == 'home/my-coin'): ?> active <?php endif; ?>"><a href="<?php echo e(route('myCoin')); ?>"><i class="fa fa-users" aria-hidden="true"></i> <span><?php echo e($gnl->cur); ?> Purchase Log</span></a></li>
      <li class="<?php if(request()->path() == 'home/change-password'): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('changepass')); ?>"><i class="fa fa-lock" aria-hidden="true"></i> <span>Password</span></a>
      </li> 
      <li class="<?php if(request()->path() == 'home/g2fa'): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('go2fa')); ?>"><i class="fa fa-shield" aria-hidden="true"></i> <span>Security</span></a>
      </li>

      <li>
        <a href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i>
        <span>SIGN OUT</span>
      </a>

      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

      </form>
    </li>

    <li><a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>

  </ul>

</div>

</div>
<div class="sidebar-bg"></div>
