<?php $__env->startSection('content'); ?>

<section class="contact-section contact-bg" id="contact" style="background-image: url(<?php echo e(asset('assets/images/logo/bc.jpg')); ?>);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="contact-form-wrapper text-center">
                	 <h3 style="color: #cc0000;">Sorry! Page Not Found</h3>
                	 <h4><a href="<?php echo e(route('home')); ?>">Back To Home</a></h4>
               	</div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>