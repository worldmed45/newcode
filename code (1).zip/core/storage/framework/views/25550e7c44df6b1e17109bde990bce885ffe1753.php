<?php $__env->startSection('content'); ?>
<div class="col-md-12 text-center">

<h3>
Please Send EXACTLY <span style="color:red"><?php echo e($bitcoin['amount']); ?> </span>BTC <br>
TO <span style="color:red"><?php echo e($bitcoin['sendto']); ?> </span>
</h3>
<br>	
<br>
<h2>SCAN TO SEND</h2>
<?php echo $bitcoin['code']; ?>	
<br>
<br>
<h3 style="color: red;">** 3 Confirmation Required To credited Your Account</h3>

</div>	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>