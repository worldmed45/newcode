<?php $__env->startSection('content'); ?>
<section class="contact-section contact-bg" id="contact" style="background-image: url(<?php echo e(asset('assets/images/logo/bc.jpg')); ?>);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="contact-form-wrapper">
                    <h2 class="text-uppercase text-center">Sign In</h2>
                   <form  method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-lg-12">
                                 <input id="username" type="text" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required autofocus>

                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                
                                <input id="password" type="password" placeholder="Password" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                            </div>
                        </div>
                        <input type="submit" value="Log In">
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>