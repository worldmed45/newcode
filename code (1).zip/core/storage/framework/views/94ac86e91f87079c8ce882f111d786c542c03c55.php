<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <i class="icon-settings font-dark"></i>
                    <span class="caption-subject bold uppercase"> Sell Log</span>
                </div>
            </div>
            <div class="portlet-body">

                <table class="table table-striped table-bordered table-hover order-column">
                <thead>
                    <tr>
                        <th>
                            Username 
                        </th>
                        <th>
                            Amount
                        </th>
                        <th>
                            Price
                        </th>
                        <th>
                            Payment Gateway
                        </th>                       
                     </tr>
                </thead>
                <tbody>
      <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                      <td>
                          <a href="<?php echo e(route('user.single', $sel->user->id)); ?>">
                            <?php echo e($sel->user->username); ?>

                          </a>
                        </td>
                        <td>
                            <?php echo e($sel->amount); ?> <?php echo e($gnl->cur); ?>   
                        </td> 
                        <td>
                            <?php echo e($sel->ico->price); ?> USD  
                        </td>
                        <td>
                            <?php echo e($sel->gateway->name); ?>

                        </td>
                     </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      <tbody>
           </table>
           <?php echo $sells->render(); ?>
        </div>
      
      </div><!-- row -->
      </div>
    </div>
  </div>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>